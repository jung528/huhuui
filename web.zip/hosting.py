from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import os
import subprocess
import threading
import time
import secrets
import signal
import sys
import tempfile
import json
import psutil
import shutil
from werkzeug.utils import secure_filename
from pathlib import Path
import queue
from datetime import datetime, timezone
import zipfile
import select
import os
import re
import uuid

app = Flask(__name__)
# Generate a secure random key
app.config['SECRET_KEY'] = secrets.token_hex(32)  # Generates a 64-character hex string
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SESSION_TYPE'] = 'simple'
db = SQLAlchemy(app)

# Add configuration for file uploads
UPLOAD_FOLDER = os.path.abspath('filestab')
CONTAINER_FOLDER = os.path.join(UPLOAD_FOLDER, 'container')
ALLOWED_EXTENSIONS = {'txt', 'py', 'json', 'cfg', 'yml', 'yaml', 'env', 'zip', 'rar', '7z'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Ensure upload directories exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(CONTAINER_FOLDER, exist_ok=True)

# Global variables for process management
current_process = None
output_queue = queue.Queue()
output_lock = threading.Lock()
process_output = []

# Add these constants for token storage
TOKEN_FOLDER = "tokens"
GUEST_FOLDER = "khach"

# Ensure token folders exist
os.makedirs(TOKEN_FOLDER, exist_ok=True)
os.makedirs(GUEST_FOLDER, exist_ok=True)

# ANSI color codes for Windows support
ANSI_COLORS = {
    'black': '\033[30m',
    'red': '\033[31m',
    'green': '\033[32m',
    'yellow': '\033[33m',
    'blue': '\033[34m',
    'magenta': '\033[35m',
    'cyan': '\033[36m',
    'white': '\033[37m',
    'bright_black': '\033[90m',
    'bright_red': '\033[91m',
    'bright_green': '\033[92m',
    'bright_yellow': '\033[93m',
    'bright_blue': '\033[94m',
    'bright_magenta': '\033[95m',
    'bright_cyan': '\033[96m',
    'bright_white': '\033[97m',
    'reset': '\033[0m',
    'bold': '\033[1m',
    'dim': '\033[2m',
    'italic': '\033[3m',
    'underline': '\033[4m',
    'blink': '\033[5m',
    'reverse': '\033[7m',
    'hidden': '\033[8m',
    'strike': '\033[9m',
}

def colorize(text, color):
    """Add color to text"""
    return f"{ANSI_COLORS.get(color, '')}{text}{ANSI_COLORS['reset']}"

def process_ansi_colors(text):
    """Process ANSI color codes in text"""
    # Keep the original ANSI codes
    return text

def clean_ansi(text):
    """Remove ANSI escape sequences for logging"""
    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
    return ansi_escape.sub('', text)

def format_console_output(text):
    """Format console output with proper line breaks and color support"""
    # Process ANSI color codes
    text = process_ansi_colors(text)
    
    # Handle carriage returns properly
    lines = []
    current_line = ""
    
    for char in text:
        if char == '\r':
            # Carriage return - move to start of line
            current_line = ""
        elif char == '\n':
            # New line - add current line to lines and start new one
            lines.append(current_line)
            current_line = ""
        else:
            current_line += char
    
    # Add any remaining content
    if current_line:
        lines.append(current_line)
    
    # Join lines with proper line endings
    return '\n'.join(lines)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    api_key = db.Column(db.String(32), unique=True)
    auth_token = db.Column(db.String(32), unique=True)
    token_created_at = db.Column(db.DateTime)
    discord_channel_id = db.Column(db.String(20))
    files = db.relationship('File', backref='owner', lazy=True)

    def __init__(self, username, password, email=None, is_admin=False):
        self.username = username
        self.password = password
        self.email = email or f"{username}@aesthosting.com"  # Default email if none provided
        self.is_admin = is_admin
        self.api_key = secrets.token_hex(16)
        self.auth_token = None
        self.token_created_at = None

    def generate_auth_token(self):
        self.auth_token = secrets.token_hex(16)
        self.token_created_at = datetime.now(timezone.utc)
        return self.auth_token

    def clear_auth_token(self):
        self.auth_token = None
        self.token_created_at = None

    def is_token_valid(self, max_age_hours=24):
        if not self.auth_token or not self.token_created_at:
            return False
        age = datetime.now(timezone.utc) - self.token_created_at
        return age.total_seconds() < (max_age_hours * 3600)

    def set_password(self, password):
        self.password = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password, password)

class Key(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(64), unique=True, nullable=False)
    is_valid = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    used_at = db.Column(db.DateTime)
    used_by = db.Column(db.Integer, db.ForeignKey('user.id'))

class File(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    path = db.Column(db.String(512), nullable=False)
    type = db.Column(db.String(50))  # 'file' or 'directory'
    size = db.Column(db.Integer)  # in bytes
    modified = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))

class PythonProcess:
    def __init__(self):
        self.process = None
        self.output = []
        self.output_thread = None
        self.error_thread = None
        self.running = False
        self.temp_file = None
        self.max_output_lines = 1000  # Limit output buffer

    def start(self, code):
        if self.running:
            return False, "Process is already running"

        try:
            # Create a temporary file for the code
            self.temp_file = tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False)
            self.temp_file.write(code)
            self.temp_file.close()

            # Start the process with stdin pipe enabled
            self.process = subprocess.Popen(['python', self.temp_file.name],
                                          stdout=subprocess.PIPE,
                                          stderr=subprocess.PIPE,
                                          stdin=subprocess.PIPE,  # Enable stdin
                                          text=True,
                                          bufsize=1,
                                          universal_newlines=True)
            
            self.running = True
            
            # Start output reading threads
            self.output_thread = threading.Thread(target=self._read_output, args=(self.process.stdout,))
            self.error_thread = threading.Thread(target=self._read_output, args=(self.process.stderr,))
            self.output_thread.start()
            self.error_thread.start()
            
            return True, "Process started successfully"
        except Exception as e:
            return False, f"Error starting process: {str(e)}"

    def send_input(self, input_text):
        if not self.running or not self.process:
            return False, "No process is running"
        
        try:
            # Add newline if not present
            if not input_text.endswith('\n'):
                input_text += '\n'
            
            # Send input to process
            self.process.stdin.write(input_text)
            self.process.stdin.flush()
            return True, "Input sent successfully"
        except Exception as e:
            return False, f"Error sending input: {str(e)}"

    def stop(self):
        if not self.running:
            return False, "No process is running"

        try:
            if self.process:
                os.kill(self.process.pid, signal.SIGTERM)
                self.process.wait(timeout=5)
            self.cleanup()
            return True, "Process stopped successfully"
        except Exception as e:
            return False, f"Error stopping process: {str(e)}"

    def restart(self, code):
        stop_success, stop_message = self.stop()
        if not stop_success:
            return False, stop_message
        return self.start(code)

    def _read_output(self, pipe):
        while self.running:
            try:
                line = pipe.readline()
                if not line:
                    break
                with output_lock:
                    self.output.append(line.strip())
                    # Limit buffer size
                    if len(self.output) > self.max_output_lines:
                        self.output = self.output[-self.max_output_lines:]
            except Exception as e:
                with output_lock:
                    self.output.append(f"[Error reading output: {str(e)}]")
                time.sleep(0.1)

    def cleanup(self):
        self.running = False
        if self.process:
            try:
                self.process.kill()
            except:
                pass
        if self.temp_file:
            try:
                os.unlink(self.temp_file.name)
            except:
                pass
        self.process = None
        self.temp_file = None

    def get_output(self):
        with output_lock:
            output = self.output.copy()
            self.output.clear()
        return output

    def is_running(self):
        if self.process:
            return self.process.poll() is None
        return False

class ProcessStats:
    def __init__(self):
        self.network_in = 0
        self.network_out = 0
        self._last_bytes_recv = 0
        self._last_bytes_sent = 0
        self.last_update = time.time()
        self.disk_usage = 0
        self.cpu_percent = 0
        self.memory_percent = 0
        self.process = None
        self._is_monitoring = False
        self._monitor_thread = None
        self._stop_event = threading.Event()

    def start_monitoring(self, process_pid):
        """Start monitoring process resources"""
        if not self._is_monitoring:
            self._is_monitoring = True
            self._stop_event.clear()
            self.process = psutil.Process(process_pid)
            self._monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
            self._monitor_thread.start()

    def stop_monitoring(self):
        """Stop monitoring process resources"""
        self._stop_event.set()
        self._is_monitoring = False
        self.process = None
        self._monitor_thread = None
        self.reset()

    def _monitor_loop(self):
        """Monitor process resources in a loop"""
        while self._is_monitoring and not self._stop_event.is_set():
            try:
                if self.process and self.process.is_running():
                    self.update()
                else:
                    self.reset()
                    break
                time.sleep(2)  # Update every 2 seconds to reduce CPU usage
            except:
                self.reset()
                break

    def update(self):
        """Update process statistics"""
        try:
            if self.process and self.process.is_running():
                # Update process stats first
                try:
                    self.cpu_percent = self.process.cpu_percent() / psutil.cpu_count()
                    self.memory_percent = self.process.memory_percent()
                except:
                    self.cpu_percent = 0
                    self.memory_percent = 0

                # Update network stats less frequently
                current_time = time.time()
                if current_time - self.last_update >= 5:  # Update network stats every 5 seconds
                    try:
                        net_io = psutil.net_io_counters()
                        time_diff = current_time - self.last_update
                        
                        if time_diff > 0:
                            self.network_in = (net_io.bytes_recv - self._last_bytes_recv) / time_diff
                            self.network_out = (net_io.bytes_sent - self._last_bytes_sent) / time_diff
                        
                        self._last_bytes_recv = net_io.bytes_recv
                        self._last_bytes_sent = net_io.bytes_sent
                        self.last_update = current_time

                        # Update disk usage (only check root directory)
                        disk = psutil.disk_usage('/')
                        self.disk_usage = disk.percent
                    except:
                        self.network_in = 0
                        self.network_out = 0
                        self.disk_usage = 0
        except:
            self.reset()

    def reset(self):
        """Reset all statistics"""
        self.network_in = 0
        self.network_out = 0
        self._last_bytes_recv = 0
        self._last_bytes_sent = 0
        self.disk_usage = 0
        self.cpu_percent = 0
        self.memory_percent = 0

    def get_stats(self):
        """Get current statistics"""
        if not self._is_monitoring:
            return {
                'cpu': 0,
                'memory': 0,
                'disk': 0,
                'network_in': '0 B/s',
                'network_out': '0 B/s',
                'status': 'stopped'
            }
        
        return {
            'cpu': round(self.cpu_percent, 1),
            'memory': round(self.memory_percent, 1),
            'disk': round(self.disk_usage, 1),
            'network_in': self._format_network(self.network_in),
            'network_out': self._format_network(self.network_out),
            'status': 'running' if self.process and self.process.is_running() else 'stopped'
        }

    def _format_network(self, bytes_per_sec):
        """Format network speed in human readable format"""
        if bytes_per_sec < 1024:
            return f"{round(bytes_per_sec, 1)} B/s"
        elif bytes_per_sec < 1024 * 1024:
            return f"{round(bytes_per_sec/1024, 1)} KB/s"
        else:
            return f"{round(bytes_per_sec/1024/1024, 1)} MB/s"

process_stats = ProcessStats()

python_process = PythonProcess()

def create_admin():
    # Check if admin user already exists
    admin = User.query.filter_by(username='admin').first()
    if not admin:
        # Create admin user with default password '123'
        hashed_password = generate_password_hash('123')
        admin = User(username='admin', password=hashed_password, is_admin=True, api_key=secrets.token_hex(32))
        db.session.add(admin)
        db.session.commit()
        print("Admin user created successfully")
    else:
        print("Admin user already exists")

@app.route('/')
def index():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        try:
            # Try to get data from JSON first
            if request.is_json:
                data = request.get_json()
                username = data.get('username')
                password = data.get('password')
            else:
                # Fall back to form data
                username = request.form.get('username')
                password = request.form.get('password')
            
            if not username or not password:
                return jsonify({'error': 'Username and password are required'}), 400
            
            user = User.query.filter_by(username=username).first()
            
            if user and check_password_hash(user.password, password):
                # Generate and save token
                token = secrets.token_hex(32)
                token_file = save_token(username, token)
                
                session['user_id'] = user.id
                session['is_admin'] = user.is_admin
                return jsonify({
                    'success': True,
                    'token': token,
                    'token_file': token_file
                })
            else:
                return jsonify({'error': 'Invalid username or password'}), 401
                
        except Exception as e:
            print(f"Login error: {str(e)}")
            return jsonify({'error': 'An error occurred during login'}), 500
            
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'GET':
        return render_template('register.html')
        
    try:
        data = request.get_json()
        email = data.get('email')
        username = data.get('username')
        password = data.get('password')

        if not email or not username or not password:
            return jsonify({
                'success': False,
                'message': 'Email, username and password are required'
            }), 400

        # Check if email already exists
        if User.query.filter_by(email=email).first():
            return jsonify({
                'success': False,
                'message': 'Email already registered'
            }), 400

        # Check if username already exists  
        if User.query.filter_by(username=username).first():
            return jsonify({
                'success': False, 
                'message': 'Username already taken'
            }), 400

        # Create user with hashed password
        hashed_password = generate_password_hash(password)
        user = User(username=username, password=hashed_password, email=email)
        
        db.session.add(user)
        db.session.commit()

        # Generate and save token
        token = secrets.token_hex(32)
        token_file = save_token(username, token)
        
        return jsonify({
            'success': True,
            'message': 'Registration successful',
            'token': token,
            'token_file': token_file
        })

    except Exception as e:
        db.session.rollback()
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@app.route('/logout')
def logout():
    if 'user_id' in session:
        user = User.query.get(session['user_id'])
        if user:
            user.auth_token = None
            user.token_created_at = None
            db.session.commit()
    
    session.clear()
    return redirect(url_for('login'))

@app.route('/run_code', methods=['POST'])
def run_code():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401

    # Check if user has valid API key
    user = User.query.get(session['user_id'])
    if not user.api_key:
        return jsonify({'error': 'API key required', 'need_key': True}), 403

    try:
        # Đường dẫn thư mục container
        container_path = os.path.abspath(CONTAINER_FOLDER)
        os.makedirs(container_path, exist_ok=True)
        os.chdir(container_path)

        # Kiểm tra xem main.py có tồn tại không
        main_file_path = os.path.join(container_path, 'main.py')
        if not os.path.exists(main_file_path):
            with output_lock:
                process_output.clear()
                process_output.append("\x1b[96mcontainer@pterodactyl\x1b[0m~ Server marked as offline...")
                process_output.append("\x1b[93maest hosting AI\x1b[0m: main.py not found. Please upload main.py to container folder.")
            return jsonify({'error': 'main.py not found'}), 400

        # Clear log cũ & stop process cũ
        stop_process()
        with output_lock:
            process_output.clear()
            process_output.append("\x1b[96mcontainer@pterodactyl\x1b[0m~ Server marked as stopping...")
            process_output.append("\x1b[96mcontainer@pterodactyl\x1b[0m~ Server marked as offline...")
            process_output.append("\x1b[93maest hosting AI\x1b[0m: Checking server disk space usage, this could take a few seconds...")
            process_output.append("\x1b[93maest hosting AI\x1b[0m: Updating process configuration files...")
            process_output.append("\x1b[93maest hosting AI\x1b[0m: Ensuring file permissions are set correctly, this could take a few seconds...")
            process_output.append("\x1b[96mcontainer@pterodactyl\x1b[0m~ Server marked as starting...")
            process_output.append("\x1b[93maest hosting AI\x1b[0m: Pulling Docker container image, this could take a few minutes to complete...")
            process_output.append("\x1b[93maest hosting AI\x1b[0m: Finished pulling Docker container image")
            process_output.append(f"\x1b[92mPython {sys.version.split()[0]}\x1b[0m")
            process_output.append("\x1b[96m:/home/container$\x1b[0m ")

        # Set environment variables for color support
        env = os.environ.copy()
        env['PYTHONIOENCODING'] = 'utf-8'
        env['PYTHONUNBUFFERED'] = '1'
        env['FORCE_COLOR'] = '1'
        env['TERM'] = 'xterm-256color'
        env['COLORTERM'] = 'truecolor'
        env['ANSICON'] = '1'

        # Enable Windows console virtual terminal sequences
        if os.name == 'nt':
            import ctypes
            kernel32 = ctypes.windll.kernel32
            kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)

        # Chạy main.py với hỗ trợ màu sắc
        cmd = [sys.executable, 'main.py']
        try:
            global current_process
            if os.name == 'nt':  # Windows
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                current_process = subprocess.Popen(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    stdin=subprocess.PIPE,
                    bufsize=1,
                    universal_newlines=False,
                    cwd=container_path,
                    creationflags=subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW,
                    startupinfo=startupinfo,
                    env=env
                )
            else:  # Linux/Unix
                current_process = subprocess.Popen(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    stdin=subprocess.PIPE,
                    bufsize=1,
                    universal_newlines=False,
                    cwd=container_path,
                    preexec_fn=os.setsid,
                    env=env
                )

            # Start monitoring process resources
            process_stats.start_monitoring(current_process.pid)

            with output_lock:
                process_output.append("\x1b[93maest hosting AI\x1b[0m: Running main.py")

            # Start output reader in a daemon thread
            output_thread = threading.Thread(target=read_output, daemon=True)
            output_thread.start()

            return jsonify({'message': 'Process started successfully'})

        except Exception as e:
            with output_lock:
                process_output.append(f"\x1b[91maest hosting AI\x1b[0m: Failed to start process: {str(e)}")
            return jsonify({'error': str(e)}), 500

    except Exception as e:
        with output_lock:
            process_output.append(f"\x1b[91maest hosting AI\x1b[0m: Fatal error: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/stop_code', methods=['POST'])
def stop_code():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    try:
        if stop_process():
            return jsonify({'message': 'Process stopped successfully'})
        return jsonify({'error': 'Failed to stop process'}), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/restart_code', methods=['POST'])
def restart_code():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    try:
        # Stop current process
        stop_process()
        # Start new process
        return run_code()
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/get_output')
def get_output():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    try:
        with output_lock:
            output = process_output.copy()
            # Only clear if there's actual output
            if output:
                process_output.clear()
        
        # Add response headers for better client handling
        response = jsonify({
            'output': output,
            'is_running': current_process is not None and current_process.poll() is None
        })
        response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
        response.headers['Pragma'] = 'no-cache'
        response.headers['Expires'] = '0'
        response.headers['X-Accel-Buffering'] = 'no'
        return response
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/get_status')
def get_status():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    is_running = current_process is not None and current_process.poll() is None
    return jsonify({'is_running': is_running})

@app.route('/save_network_config', methods=['POST'])
def save_network_config():
    if 'username' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    try:
        data = request.json
        port = data.get('port')
        ip = data.get('ip')
        
        # Save configuration to a file
        config = {
            'port': port,
            'ip': ip
        }
        with open('network_config.json', 'w') as f:
            json.dump(config, f)
        
        return jsonify({'message': 'Network configuration saved successfully'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/save_proxy_config', methods=['POST'])
def save_proxy_config():
    if 'username' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    try:
        data = request.json
        proxy_type = data.get('proxyType')
        proxy_address = data.get('proxyAddress')
        
        # Save configuration to a file
        config = {
            'type': proxy_type,
            'address': proxy_address
        }
        with open('proxy_config.json', 'w') as f:
            json.dump(config, f)
        
        return jsonify({'message': 'Proxy configuration saved successfully'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/save_startup_config', methods=['POST'])
def save_startup_config():
    if 'username' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    try:
        data = request.json
        auto_start = data.get('autoStart')
        restart_policy = data.get('restartPolicy')
        
        # Save configuration to a file
        config = {
            'autoStart': auto_start,
            'restartPolicy': restart_policy
        }
        with open('startup_config.json', 'w') as f:
            json.dump(config, f)
        
        return jsonify({'message': 'Startup configuration saved successfully'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/get_stats')
def get_stats():
    if 'username' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    try:
        # Get CPU usage
        cpu = psutil.cpu_percent()
        
        # Get memory usage
        memory = psutil.Process(os.getpid()).memory_info().rss / 1024 / 1024  # Convert to MB
        
        # Calculate uptime
        uptime = time.time() - psutil.boot_time()
        days = int(uptime // (24 * 3600))
        hours = int((uptime % (24 * 3600)) // 3600)
        minutes = int((uptime % 3600) // 60)
        uptime_str = f"{days}d {hours}h {minutes}m"
        
        return jsonify({
            'cpu': round(cpu, 1),
            'memory': round(memory, 1),
            'uptime': uptime_str
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def sync_files_to_database():
    """Sync files from filesystem to database on startup"""
    try:
        # Get all users
        users = User.query.all()
        
        for user in users:
            # Create user directory if it doesn't exist
            user_dir = os.path.join(CONTAINER_FOLDER, str(user.id))
            os.makedirs(user_dir, exist_ok=True)
            
            # Get all files in user directory
            for entry in os.scandir(user_dir):
                if entry.is_file():
                    # Check if file exists in database
                    existing_file = File.query.filter_by(
                        name=entry.name,
                        user_id=user.id
                    ).first()
                    
                    if not existing_file:
                        # Add to database
                        new_file = File(
                            name=entry.name,
                            path=entry.path,
                            type='file',
                            size=entry.stat().st_size,
                            user_id=user.id
                        )
                        db.session.add(new_file)
                elif entry.is_dir():
                    # Check if directory exists in database
                    existing_dir = File.query.filter_by(
                        name=entry.name,
                        user_id=user.id,
                        type='directory'
                    ).first()
                    
                    if not existing_dir:
                        # Add to database
                        new_dir = File(
                            name=entry.name,
                            path=entry.path,
                            type='directory',
                            user_id=user.id
                        )
                        db.session.add(new_dir)
            
            db.session.commit()
    except Exception as e:
        print(f"Error syncing files to database: {e}")
        db.session.rollback()

@app.route('/list_files')
def list_files():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    try:
        user = User.query.get(session['user_id'])
        if not user:
            return jsonify({'error': 'User not found'}), 404
            
        # Get user-specific directory
        user_dir = os.path.join(CONTAINER_FOLDER, str(session['user_id']))
        os.makedirs(user_dir, exist_ok=True)
        
        # Get files from database
        db_files = File.query.filter_by(user_id=session['user_id']).all()
        file_list = []
        
        # Check if physical files exist and update database if needed
        for file in db_files:
            if os.path.exists(file.path):
                file_info = {
                    'name': file.name,
                    'type': file.type,
                    'size': _format_size(file.size) if file.type == 'file' else None,
                    'modified': file.modified.strftime('%Y-%m-%d %H:%M:%S') if file.modified else None
                }
                file_list.append(file_info)
            else:
                # File exists in database but not on disk, remove from database
                db.session.delete(file)
        
        # Check for files on disk that aren't in database
        for entry in os.scandir(user_dir):
            if entry.is_file():
                # Check if file is already in database
                existing_file = File.query.filter_by(name=entry.name, user_id=session['user_id']).first()
                if not existing_file:
                    # Add to database
                    new_file = File(
                        name=entry.name,
                        path=entry.path,
                        type='file',
                        size=entry.stat().st_size,
                        user_id=session['user_id']
                    )
                    db.session.add(new_file)
                    
                    file_info = {
                        'name': entry.name,
                        'type': 'file',
                        'size': _format_size(entry.stat().st_size),
                        'modified': time.ctime(entry.stat().st_mtime)
                    }
                    file_list.append(file_info)
            elif entry.is_dir():
                # Check if directory is already in database
                existing_dir = File.query.filter_by(name=entry.name, user_id=session['user_id'], type='directory').first()
                if not existing_dir:
                    # Add to database
                    new_dir = File(
                        name=entry.name,
                        path=entry.path,
                        type='directory',
                        user_id=session['user_id']
                    )
                    db.session.add(new_dir)
                    
                    file_info = {
                        'name': entry.name,
                        'type': 'directory'
                    }
                    file_list.append(file_info)
        
        db.session.commit()
        return jsonify({'files': file_list})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
        
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
        
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
        
    if file and allowed_file(file.filename):
        try:
            # Create user-specific directory if it doesn't exist
            user_dir = os.path.join(CONTAINER_FOLDER, str(session['user_id']))
            os.makedirs(user_dir, exist_ok=True)
            
            # Save file to user-specific directory
            filename = secure_filename(file.filename)
            file_path = os.path.join(user_dir, filename)
            file.save(file_path)
            
            # Check if file already exists in database
            existing_file = File.query.filter_by(name=filename, user_id=session['user_id']).first()
            if existing_file:
                # Update existing file record
                existing_file.path = file_path
                existing_file.size = os.path.getsize(file_path)
                existing_file.modified = datetime.now(timezone.utc)
            else:
                # Create new file record
                new_file = File(
                    name=filename,
                    path=file_path,
                    type='file',
                    size=os.path.getsize(file_path),
                    user_id=session['user_id']
                )
                db.session.add(new_file)
            
            db.session.commit()
            
            return jsonify({'message': 'File uploaded successfully'})
        except Exception as e:
            db.session.rollback()
            return jsonify({'error': str(e)}), 500
            
    return jsonify({'error': 'File type not allowed'}), 400

@app.route('/delete_file', methods=['POST'])
def delete_file():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
        
    try:
        data = request.json
        filename = data.get('name')
        
        if not filename:
            return jsonify({'error': 'Filename is required'}), 400
            
        file = File.query.filter_by(name=filename, user_id=session['user_id']).first()
        if not file:
            return jsonify({'error': 'File not found'}), 404
            
        # Delete physical file
        if os.path.exists(file.path):
            os.remove(file.path)
            
        # Delete from database
        db.session.delete(file)
        db.session.commit()
        
        return jsonify({'message': 'File deleted successfully'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/rename_file', methods=['POST'])
def rename_file():
    if 'user_id' not in session:
        return jsonify({'error': 'Vui lòng đăng nhập để thực hiện thao tác này'}), 401
    
    try:
        data = request.get_json()
        old_name = data.get('old_name')
        new_name = data.get('new_name')
        
        if not old_name or not new_name:
            return jsonify({'error': 'Thiếu tên file cũ hoặc tên file mới'}), 400
            
        # Get file from database
        file = File.query.filter_by(name=old_name, user_id=session['user_id']).first()
        if not file:
            return jsonify({'error': 'Không tìm thấy file'}), 404
            
        # Get old and new paths
        old_path = file.path
        new_path = os.path.join(os.path.dirname(file.path), new_name)
        
        # Check if new file already exists
        if os.path.exists(new_path):
            # If old and new names are the same (ignoring case), use a temporary file
            if old_name.lower() == new_name.lower():
                temp_path = new_path + '.tmp'
                os.rename(old_path, temp_path)
                os.rename(temp_path, new_path)
            else:
                return jsonify({'error': 'File đã tồn tại'}), 400
        else:
            # Rename file
            os.rename(old_path, new_path)
            
        # Update database
        file.name = new_name
        file.path = new_path
        file.modified = datetime.now(timezone.utc)
        db.session.commit()
        
        return jsonify({'message': 'Đã đổi tên file thành công'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Lỗi khi đổi tên file: {str(e)}'}), 500

@app.route('/create_directory', methods=['POST'])
def create_directory():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
        
    try:
        data = request.json
        dirname = data.get('name')
        
        if not dirname:
            return jsonify({'error': 'Directory name is required'}), 400
            
        dir_path = os.path.join(CONTAINER_FOLDER, dirname)
        if not os.path.exists(dir_path):
            os.makedirs(dir_path)
            
            # Save directory info to database
            new_dir = File(
                name=dirname,
                path=dir_path,
                type='directory',
                user_id=session['user_id']
            )
            db.session.add(new_dir)
            db.session.commit()
            
            return jsonify({'message': 'Directory created successfully'})
        else:
            return jsonify({'error': 'Directory already exists'}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/get_process_stats')
def get_process_stats():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    return jsonify(process_stats.get_stats())

@app.route('/extract_zip', methods=['POST'])
def extract_zip():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401

    try:
        data = request.json
        filename = data.get('filename')
        if not filename:
            return jsonify({'error': 'Filename is required'}), 400

        # Get file from database
        file = File.query.filter_by(name=filename, user_id=session['user_id']).first()
        if not file:
            return jsonify({'error': 'File not found'}), 404
            
        # Get absolute path to the zip file
        zip_path = file.path
        
        # Check if file exists and is a zip file
        if not os.path.exists(zip_path):
            return jsonify({'error': f'File {filename} not found'}), 404
        if not filename.lower().endswith('.zip'):
            return jsonify({'error': 'Not a zip file'}), 400

        # Create user-specific directory if it doesn't exist
        user_dir = os.path.join(CONTAINER_FOLDER, str(session['user_id']))
        os.makedirs(user_dir, exist_ok=True)

        # Extract the zip file
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            # Get list of files to extract
            file_list = zip_ref.namelist()
            
            # Extract all files to user directory
            zip_ref.extractall(user_dir)
            
            # Add extracted files to database
            for extracted_file in file_list:
                # Skip directories
                if not extracted_file.endswith('/'):
                    file_path = os.path.join(user_dir, extracted_file)
                    if os.path.exists(file_path):
                        # Check if file already exists in database
                        existing_file = File.query.filter_by(
                            name=os.path.basename(extracted_file),
                            user_id=session['user_id']
                        ).first()
                        
                        if existing_file:
                            # Update existing file record
                            existing_file.path = file_path
                            existing_file.size = os.path.getsize(file_path)
                            existing_file.modified = datetime.now(timezone.utc)
                        else:
                            # Create new file record
                            new_file = File(
                                name=os.path.basename(extracted_file),
                                path=file_path,
                                type='file',
                                size=os.path.getsize(file_path),
                                user_id=session['user_id']
                            )
                            db.session.add(new_file)
            
            db.session.commit()
            
        return jsonify({'message': f'File {filename} extracted successfully'})
    except zipfile.BadZipFile:
        return jsonify({'error': 'Invalid or corrupted zip file'}), 400
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/send_input', methods=['POST'])
def send_input():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    try:
        data = request.json
        input_text = data.get('input')
        
        if not input_text:
            return jsonify({'error': 'Input text is required'}), 400
            
        if not current_process or current_process.poll() is not None:
            return jsonify({'error': 'No process is running. Please start the process first.'}), 400
            
        try:
            if not input_text.endswith('\n'):
                input_text += '\n'
            
            current_process.stdin.write(input_text.encode('utf-8'))
            current_process.stdin.flush()
            
            with output_lock:
                process_output.append(f"\033[96m> {input_text.strip()}\033[0m")
            
            time.sleep(0.2)
            
            response_lines = []
            try:
                while True:
                    try:
                        if os.name == 'nt':
                            line = current_process.stdout.readline()
                            if not line:
                                break
                        else:
                            if select.select([current_process.stdout], [], [], 0.1)[0]:
                                line = current_process.stdout.readline()
                                if not line:
                                    break
                            else:
                                break
                        
                        decoded_line = line.decode('utf-8', errors='replace').rstrip()
                        if decoded_line:
                            # Don't process ANSI codes, keep them as is
                            response_lines.append(decoded_line)
                            with output_lock:
                                process_output.append(decoded_line)
                    except Exception as e:
                        print(f"Error reading line: {e}")
                        break
            except Exception as e:
                print(f"Error reading response: {e}")
            
            return jsonify({
                'message': 'Input sent successfully',
                'response': response_lines
            })
        except Exception as e:
            return jsonify({'error': f'Failed to send input: {str(e)}'}), 500
    except Exception as e:
        return jsonify({'error': str(e)}), 500

def read_output():
    global process_output
    try:
        while current_process and current_process.poll() is None:
            try:
                # Read output without blocking
                if os.name == 'nt':  # Windows
                    line = current_process.stdout.readline()
                else:  # Linux/Unix
                    if select.select([current_process.stdout], [], [], 0.1)[0]:
                        line = current_process.stdout.readline()
                    else:
                        time.sleep(0.1)
                        continue
                
                if line:
                    try:
                        # Keep original ANSI codes in the output
                        decoded_line = line.decode('utf-8', errors='replace').rstrip()
                        if decoded_line:
                            with output_lock:
                                # Use raw ANSI escape sequences
                                process_output.append(decoded_line)
                                if len(process_output) > 1000:
                                    process_output = process_output[-1000:]
                    except Exception as e:
                        with output_lock:
                            process_output.append(f"\x1b[91maest hosting AI\x1b[0m: Error decoding output: {str(e)}")
                else:
                    # If no output and process is still running, wait a bit
                    if current_process and current_process.poll() is None:
                        time.sleep(0.1)
                    else:
                        break
            except Exception as e:
                with output_lock:
                    process_output.append(f"\x1b[91maest hosting AI\x1b[0m: Error reading line: {str(e)}")
                time.sleep(0.1)
        
        # Process has ended
        if current_process:
            return_code = current_process.returncode
            with output_lock:
                if return_code == 0:
                    process_output.append("\x1b[92maest hosting AI\x1b[0m: Process completed successfully")
                elif return_code < 0:
                    process_output.append(f"\x1b[91maest hosting AI\x1b[0m: Process terminated by signal {-return_code}")
                else:
                    error_msg = {
                        3221225786: "Process crashed - Please check your code for errors",
                        1: "Process ended with errors",
                        2: "Process interrupted by user",
                        3221225477: "Process crashed - Access violation",
                        3221225501: "Process crashed - Stack overflow",
                    }.get(return_code, f"Process ended with return code {return_code}")
                    process_output.append(f"\x1b[91maest hosting AI\x1b[0m: {error_msg}")
                process_output.append("\x1b[96mcontainer@pterodactyl\x1b[0m~ Server marked as offline...")
    except Exception as e:
        with output_lock:
            process_output.append(f"\x1b[91maest hosting AI\x1b[0m: Error reading output: {str(e)}")

def _format_size(size):
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size < 1024:
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} TB"

def stop_process():
    global current_process
    if current_process:
        try:
            if os.name == 'nt':
                current_process.send_signal(signal.CTRL_BREAK_EVENT)
                time.sleep(0.5)
                if current_process.poll() is None:
                    current_process.kill()
            else:
                os.killpg(os.getpgid(current_process.pid), signal.SIGTERM)
                time.sleep(0.5)
                if current_process.poll() is None:
                    os.killpg(os.getpgid(current_process.pid), signal.SIGKILL)
            
            # Stop monitoring process resources
            process_stats.stop_monitoring()
            
            try:
                current_process.wait(timeout=2)
            except:
                pass
            
            current_process = None
            with output_lock:
                process_output.append("\x1b[96mcontainer@pterodactyl\x1b[0m~ Server marked as stopping...")
                process_output.append("\x1b[93maest hosting AI\x1b[0m: Process stopped")
                process_output.append("\x1b[96mcontainer@pterodactyl\x1b[0m~ Server marked as offline...")
            return True
        except Exception as e:
            print(f"Error stopping process: {e}")
            with output_lock:
                process_output.append(f"\x1b[91maest hosting AI\x1b[0m: Error stopping process: {str(e)}")
            process_stats.stop_monitoring()
            current_process = None
            return False
    return True

@app.route('/verify_key', methods=['POST'])
def verify_key():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    try:
        data = request.json
        key_value = data.get('key')
        
        if not key_value:
            return jsonify({'error': 'Key is required'}), 400
            
        key = Key.query.filter_by(key=key_value, is_valid=True).first()
        if not key:
            return jsonify({'error': 'Invalid key'}), 400
            
        # Mark key as used
        key.is_valid = False
        key.used_at = datetime.now(timezone.utc)
        key.used_by = session['user_id']
        
        # Generate and set API key for user
        user = User.query.get(session['user_id'])
        if user:
            user.api_key = secrets.token_hex(32)
            
        db.session.commit()
        
        return jsonify({
            'message': 'Key verified successfully',
            'api_key': user.api_key
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/check_auth')
def check_auth():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    return jsonify({'authenticated': True})

@app.route('/save_channel_id', methods=['POST'])
def save_channel_id():
    return jsonify({'error': 'Route không tồn tại'}), 404

@app.route('/get_channel_id', methods=['GET'])
def get_channel_id():
    return jsonify({'error': 'Route không tồn tại'}), 404

@app.route('/read_file/<filename>')
def read_file_content(filename):
    if 'user_id' not in session:
        return jsonify({'error': 'Vui lòng đăng nhập để thực hiện thao tác này'}), 401
    
    try:
        # Get file from database
        file = File.query.filter_by(name=filename, user_id=session['user_id']).first()
        if not file:
            return jsonify({'error': 'Không tìm thấy file'}), 404
            
        # Read file content
        with open(file.path, 'r', encoding='utf-8') as f:
            content = f.read()
            
        return jsonify({
            'content': content
        })
        
    except Exception as e:
        return jsonify({'error': f'Lỗi khi đọc file: {str(e)}'}), 500

@app.route('/save_file', methods=['POST'])
def save_file_content():
    if 'user_id' not in session:
        return jsonify({'error': 'Vui lòng đăng nhập để thực hiện thao tác này'}), 401
    
    try:
        data = request.get_json()
        filename = data.get('filename')
        content = data.get('content')
        
        if not filename or content is None:
            return jsonify({'error': 'Thiếu thông tin file hoặc nội dung'}), 400
            
        # Get file from database
        file = File.query.filter_by(name=filename, user_id=session['user_id']).first()
        if not file:
            return jsonify({'error': 'Không tìm thấy file'}), 404
            
        # Save file content
        with open(file.path, 'w', encoding='utf-8') as f:
            f.write(content)
            
        # Update file size and modified time
        file.size = len(content.encode('utf-8'))
        file.modified = datetime.now(timezone.utc)
        db.session.commit()
        
        return jsonify({'message': 'Đã lưu file thành công'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Lỗi khi lưu file: {str(e)}'}), 500

@app.route('/save_token', methods=['POST'])
def save_token():
    try:
        if not request.is_json:
            return jsonify({
                'success': False,
                'message': 'Request must be JSON'
            }), 400
            
        data = request.get_json()
        username = data.get('username')
        token = data.get('token')
        
        if not username or not token:
            return jsonify({
                'success': False,
                'message': 'Username and token are required'
            }), 400
            
        user = User.query.filter_by(username=username).first()
        if not user:
            return jsonify({
                'success': False,
                'message': 'User not found'
            }), 404
            
        # Generate new token and save
        user.auth_token = token
        user.token_created_at = datetime.now(timezone.utc)
        
        try:
            db.session.commit()
            return jsonify({
                'success': True,
                'message': 'Token saved successfully'
            })
        except Exception as e:
            db.session.rollback()
            return jsonify({
                'success': False,
                'message': f'Database error: {str(e)}'
            }), 500
            
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Server error: {str(e)}'
        }), 500

@app.route('/validate_token', methods=['POST'])
def validate_token():
    if not request.is_json:
        return jsonify({'error': 'Missing JSON'}), 400
        
    data = request.get_json()
    token = data.get('token')
    
    if not token:
        return jsonify({'error': 'Missing token'}), 400
        
    try:
        # Find user by token
        user = User.query.filter_by(auth_token=token).first()
        if not user:
            return jsonify({'error': 'Invalid token'}), 401
            
        # Check token age (24 hours)
        token_age = datetime.now(timezone.utc) - user.token_created_at
        if token_age.total_seconds() > 24 * 3600:  # Token expires after 24 hours
            # Clear token and force logout
            user.clear_auth_token()
            db.session.commit()
            return jsonify({'error': 'Token expired', 'expired': True}), 401
            
        return jsonify({'valid': True})
        
    except Exception as e:
        return jsonify({'error': f'Error validating token: {str(e)}'}), 500

@app.route('/dashboard')
def dashboard():
    # Get token from URL
    token = request.args.get('token')
    if not token:
        return redirect(url_for('login'))
        
    # Validate token
    user = User.query.filter_by(auth_token=token).first()
    if not user:
        return redirect(url_for('login'))
        
    # Check token age (24 hours)
    token_age = datetime.now(timezone.utc) - user.token_created_at
    if token_age.total_seconds() > 24 * 3600:
        # Clear token and force logout
        user.clear_auth_token()
        db.session.commit()
        return redirect(url_for('login'))
        
    # Set session
    session['user_id'] = user.id
    
    return render_template('dashboard.html')

# Add a background task to check and reset expired tokens
def check_expired_tokens():
    while True:
        try:
            with app.app_context():
                # Get all users with tokens
                users = User.query.filter(User.auth_token.isnot(None)).all()
                current_time = datetime.now(timezone.utc)
                
                for user in users:
                    if user.token_created_at:
                        token_age = current_time - user.token_created_at
                        if token_age.total_seconds() > 24 * 3600:
                            # Token expired, clear it
                            user.clear_auth_token()
                
                db.session.commit()
        except Exception as e:
            print(f"Error checking expired tokens: {e}")
            
        # Sleep for 5 minutes before next check
        time.sleep(300)

def init_db():
    with app.app_context():
        # Drop all tables
        db.drop_all()
        # Create all tables
        db.create_all()
        
        # Create admin user if not exists
        admin = User.query.filter_by(username='admin').first()
        if not admin:
            admin = User(
                username='admin',
                email='admin@aesthosting.com',
                password=generate_password_hash('admin'),
                is_admin=True
            )
            db.session.add(admin)
            db.session.commit()
            print("Admin user created successfully")
        else:
            print("Admin user already exists")

# Function to generate a unique token
def generate_token():
    return str(uuid.uuid4())

# Function to save token to file
def save_token(username, token, is_guest=False):
    # Create user folder if it doesn't exist
    user_folder = os.path.join(TOKEN_FOLDER, username)
    os.makedirs(user_folder, exist_ok=True)
    
    # Create token file with timestamp
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    token_file = os.path.join(user_folder, f"token_{timestamp}.json")
    
    # Save token data
    token_data = {
        "token": token,
        "created_at": datetime.now().isoformat(),
        "is_guest": is_guest
    }
    
    with open(token_file, "w") as f:
        json.dump(token_data, f, indent=2)
    
    # If guest, also save to guest folder
    if is_guest:
        guest_file = os.path.join(GUEST_FOLDER, f"token_{timestamp}.json")
        with open(guest_file, "w") as f:
            json.dump(token_data, f, indent=2)
    
    return token_file

if __name__ == '__main__':
    # Start token checker thread
    token_checker = threading.Thread(target=check_expired_tokens, daemon=True)
    token_checker.start()
    
    # Initialize database
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=True)

