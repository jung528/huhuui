// Token generation and validation
class TokenManager {
    static generateToken() {
        return Math.random().toString(36).substring(2) + Date.now().toString(36);
    }

    static async saveToken(token) {
        try {
            // Get username from session or localStorage
            const username = localStorage.getItem('username') || 'admin'; // Default to admin if not found
            
            const response = await fetch('/save_token', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ 
                    username: username,
                    token: token 
                })
            });

            if (!response.ok) {
                throw new Error('Failed to save token');
            }

            const data = await response.json();
            if (!data.success) {
                throw new Error(data.message || 'Failed to save token');
            }

            localStorage.setItem('auth_token', token);
            return true;
        } catch (error) {
            console.error('Error saving token:', error);
            throw error;
        }
    }

    static getToken() {
        return localStorage.getItem('auth_token');
    }

    static removeToken() {
        localStorage.removeItem('auth_token');
    }

    static async validateToken(token) {
        try {
            const response = await fetch('/validate_token', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ token })
            });

            if (!response.ok) {
                const data = await response.json();
                if (data.expired) {
                    // Token expired, show notification
                    Swal.fire({
                        title: 'Session Expired',
                        text: 'Your session has expired. Please log in again.',
                        icon: 'warning',
                        confirmButtonText: 'OK',
                        background: '#1a1a1a',
                        color: '#fff'
                    });
                }
                return false;
            }

            const data = await response.json();
            return data.valid === true;
        } catch (error) {
            console.error('Error validating token:', error);
            return false;
        }
    }
}

// Login form handling
document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;

            try {
                const response = await fetch('/login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ username, password })
                });

                const data = await response.json();

                if (response.ok && data.success) {
                    // Store username in localStorage
                    localStorage.setItem('username', username);
                    
                    const token = TokenManager.generateToken();
                    await TokenManager.saveToken(token);
                    
                    Swal.fire({
                        title: 'Success!',
                        text: 'Login successful',
                        icon: 'success',
                        confirmButtonText: 'OK',
                        background: '#1a1a1a',
                        color: '#fff'
                    }).then(() => {
                        window.location.href = '/';
                    });
                } else {
                    throw new Error(data.message || 'Login failed');
                }
            } catch (error) {
                Swal.fire({
                    title: 'Error!',
                    text: error.message || 'An error occurred during login',
                    icon: 'error',
                    confirmButtonText: 'OK',
                    background: '#1a1a1a',
                    color: '#fff'
                });
            }
        });
    }
});

// Validate session on protected pages
async function validateSession() {
    const token = TokenManager.getToken();
    if (!token) {
        window.location.href = '/login';
        return;
    }

    const isValid = await TokenManager.validateToken(token);
    if (!isValid) {
        TokenManager.removeToken();
        window.location.href = '/login';
    }
}

// Check token validation on protected pages
if (window.location.pathname !== '/login') {
    validateSession();
}

// Logout handling
const logoutBtn = document.querySelector('a[href="/logout"]');
if (logoutBtn) {
    logoutBtn.addEventListener('click', (e) => {
        e.preventDefault();
        TokenManager.removeToken();
        localStorage.removeItem('username'); // Clear username from localStorage
        window.location.href = '/login';
    });
}

// Export functions for global use
window.TokenManager = TokenManager;
window.validateSession = validateSession; 