print("✅ Hello from main.py!")
import time
time.sleep(10)
print("✅ Still running...")
