import discord
from discord.ext import commands
import time
from datetime import datetime

# Tạo bot với intent mặc định (selfbot không cần intent đặc biệt)
intents = discord.Intents.default()
bot = commands.Bot(command_prefix='.', self_bot=True, intents=intents)

# Lưu thời gian khởi động bot
start_time = time.time()

@bot.event
async def on_ready():
    # Đặt trạng thái là "đang test host"
    await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.playing, name="đang test host"))
    print(f'Đã đăng nhập vào selfbot: {bot.user}')

# Lệnh .checktime để kiểm tra thời gian bot đã chạy
@bot.command()
async def checktime(ctx):
    # Tính thời gian bot đã chạy (tính bằng giây)
    current_time = time.time()
    uptime_seconds = int(current_time - start_time)
    
    # Chuyển đổi giây thành giờ, phút, giây
    hours = uptime_seconds // 3600
    minutes = (uptime_seconds % 3600) // 60
    seconds = uptime_seconds % 60
    
    # Lấy thời gian hiện tại
    current_datetime = datetime.now().strftime("%H:%M:%S %d/%m/%Y")
    
    # Gửi thông báo
    await ctx.send(f"Bot đã chạy được: {hours} giờ, {minutes} phút, {seconds} giây.\nThời gian hiện tại: {current_datetime}")

# Chạy bot với token
bot.run('MTEyMTQ2NDIyNTE0ODE3ODQ2NA.GmPmNk.ITheiQcPjOdFEtxf7gh_4FHx_Gmfuq5sKERPUQ', bot=False)